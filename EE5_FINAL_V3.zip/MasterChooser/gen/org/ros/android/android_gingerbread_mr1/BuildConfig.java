/** Automatically generated file. DO NOT MODIFY */
package org.ros.android.android_gingerbread_mr1;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}