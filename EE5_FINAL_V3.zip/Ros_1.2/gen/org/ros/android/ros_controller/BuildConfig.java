/** Automatically generated file. DO NOT MODIFY */
package org.ros.android.ros_controller;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}